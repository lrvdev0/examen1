from flask import Flask, render_template, request

app = Flask(__name__)

# Ejercicio 1 - Cálculo de Compras
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/ejercicio1', methods=['GET', 'POST'])
def ejercicio1():
    if request.method == 'POST':
        nombre = request.form['nombre']
        edad = int(request.form['edad'])
        cantidad_taros = int(request.form['cantidad_taros'])
        
        precio_taro = 9000
        total_sin_descuento = cantidad_taros * precio_taro
        
        if edad >= 18 and edad <= 30:
            descuento = 0.15
        elif edad > 30:
            descuento = 0.25
        else:
            descuento = 0
        
        total_con_descuento = total_sin_descuento * (1 - descuento)
        
        return render_template('ejercicio1.html', nombre=nombre, 
                               total_sin_descuento=total_sin_descuento, 
                               total_con_descuento=total_con_descuento, 
                               descuento=descuento)
    return render_template('ejercicio1.html')

# Ejercicio 2 - Inicio de sesión
@app.route('/ejercicio2', methods=['GET', 'POST'])
def ejercicio2():
    usuarios = {"juan": "admin", "pepe": "user"}
    mensaje = ""
    
    if request.method == 'POST':
        nombre_usuario = request.form['nombre']
        contrasena = request.form['contrasena']
        
        if nombre_usuario in usuarios and usuarios[nombre_usuario] == contrasena:
            if nombre_usuario == "juan":
                mensaje = f"Bienvenido administrador {nombre_usuario}"
            elif nombre_usuario == "pepe":
                mensaje = f"Bienvenido usuario {nombre_usuario}"
        else:
            mensaje = "Usuario o Contraseña incorrectos"
    
    return render_template('ejercicio2.html', mensaje=mensaje)

if __name__ == '__main__':
    app.run(debug=True)
